Welcome to the Imago Demo.
In order to run the program, ensure that JDK 17 is installed.
The game currently has two commands implemented.
"LOOK" and "MOVE".
"LOOK" can be used to look around your current environment, 
in this case, telling you where you can go. 
"MOVE" can be used to change locations, but only to rooms that are 
adjacent to your current room.

There may be other ones. Have fun.

To begin the game, run the start.bat file.
I promise that's all it does ;)

Take a look around, and enjoy the demo.


                         ./'.            .'\.
                         './ '.        .' \.'
      _.--~~'--.._         './ '.    .' \.'       _..--'~~--._
    .'            ~~-._      './.'..'.\.'     _.~~            `.
  .'       ,;:::::;,   ~-._      .--.      _.~   ,;:::::;,      `.
 '`.      ,;.-'  `-.:;   \|~-._.-::::-._.-~;|/  ,;.-'  `-.;,      `.
'  `.     ;/  .--.  \;'   '   (::::::::)    `  ,;/  .--.  \:;    .' `.
' ,;'`.  ,;\  `--'  /;,  //;   ::::::::    ;\\ ;;\  `--'  /;'  .' `:, '
 `._,;`-. ,;`-.__.-':;'  \\;    ::::::     ;//  ,;`-.__.-':;. '`;,_.'
    `.,;'`.  `;::::'     )/"    ::::::     '\(    `;:::::;'.'`;.'
      `.,;'`.                   .::::.                   .'`;.'
        `.,;'`.               .'::::::.               .-'`;.'
          `.,;'`-.          .'  :::::: `.          .-'`;..'
            `-._,;`--.___ .'    ::::::   `.    _.-'`;_.-'
                `-.____.-'      `::::'     `-.'___.-'
                 .'.;;::::;,    \.::./   .;;::::;,`.
               .',::.-""-.::.    \  /   ,::.-""-.::.`.
              /  ;:: (_)  :;;     \/    .::  (_) ::;  \
             /   ;:`-.__.-';;      \    ;:`-.__.-';;   \
            `.`.  `::::::::'      .'     ;::::::::'  .'.'
              `.`._             .'.               _.'.'
                `-.;-._______.-'   `-._________.-;.-'